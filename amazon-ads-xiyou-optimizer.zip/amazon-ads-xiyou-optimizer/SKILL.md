---
name: amazon-ads-xiyou-optimizer
description: Analyze Amazon Sponsored Products reports together with profit, inventory, and live Xiyou MCP keyword or ASIN data, then create a verified Chinese Excel action workbook. Use when operators upload Amazon Ads reports or an AdsPilot analysis request and want negatives, staged bid changes, exact targeting, market-opportunity validation, or ASIN rank follow-up.
---

# Amazon Ads + Xiyou Optimizer

Turn operator-supplied Amazon reports into one auditable `.xlsx` optimization workbook. Amazon reports determine actual delivery, spend, orders, sales, and ACoS. Xiyou MCP data adds market demand, competition, suggested bids, keyword trends, and rank context; it never replaces Amazon actuals.

## Required capabilities

- Use `amazon-search-term-optimizer` for search-term isolation and action rules.
- Use `spreadsheets` for workbook authoring and verification.
- Use the available Xiyou MCP server (`xydc_mcp`; compatible aliases may be named `xydc_3`) for live market enrichment.

If Xiyou tools are unavailable, still analyze Amazon reports, record `西柚MCP未连接` in the workbook, and do not invent market data.

## Intake

Read [references/input-contract.md](references/input-contract.md) whenever files or an AdsPilot request bundle are supplied.

Minimum inputs:

1. Sponsored Products search-term report.
2. Sponsored Products campaign report.
3. Marketplace, currency, reporting dates, and target ACoS or acceptable acquisition cost.
4. Main ASINs and current inventory status when ASIN rank checks or scaling decisions are requested.

Recommended inputs are placement report, advertised-product report, recent 30-day Business Report, and ASIN margin/inventory data. An `AdsPilot_分析任务包.json` carries operator settings and candidate priorities but is not a substitute for the official reports.

Stop for the missing search-term report when customer search terms are absent. For other missing inputs, continue with a clearly limited analysis unless the missing choice would materially change the decision.

## Workflow

1. Preserve every source file unchanged. Validate report type, marketplace, currency, reporting period, and attribution maturity.
2. Aggregate search terms only by `[Campaign, Ad Group, Customer Search Term]`. Never merge the same term across campaigns or ad groups. Sum raw measures, then recalculate ACoS, CPC, and conversion rate.
3. Apply the Amazon action rules first: wasted-spend negative, severe or above-target bid reduction, profitable exact targeting, or observation. Profit and inventory may stop scaling but must not rewrite actual Amazon performance.
4. Select bounded Xiyou candidates from the Amazon results, then read [references/xiyou-routing.md](references/xiyou-routing.md) and call only the tools needed for the requested analysis.
5. Merge Xiyou results by normalized keyword plus marketplace; merge rank data only by exact ASIN and keyword. Keep source dates and tool names with every external record.
6. Apply [references/merge-rules.md](references/merge-rules.md). A strong market signal can raise the priority of an expansion test or recommend a smaller negative scope, but it cannot convert an Amazon no-order group into a profitable group.
7. Create one versioned Excel workbook. Keep raw Amazon and Xiyou data on separate source sheets and expose specific actions, assumptions, limitations, and follow-up dates.

## Excel deliverable

Include at least:

1. `分析摘要`
2. `建议否定精准`
3. `建议提价_精准投放`
4. `建议降低出价`
5. `行动清单`
6. `保持观察`
7. `广告活动诊断`
8. `广告位分析` when available
9. `ASIN经营诊断` when available
10. `西柚MCP市场洞察`
11. `数据问题记录`
12. Separate `原始_*` sheets for every uploaded report and Xiyou response

The action list must state priority, campaign, ad group, keyword/ASIN, Amazon metrics, recommended action, Xiyou evidence, inventory constraint, owner status, and a 7–10 day review date. Use formulas for ACoS, CPC, and conversion rate. Keep empty recommendation sheets empty instead of relaxing thresholds.

## Guardrails

- Never average row-level ACoS, CPC, conversion rate, rank, or share metrics.
- Never call an ASIN a keyword.
- Do not recommend blanket bid increases because ACoS is low or search volume is high.
- Normal bid increases are 10%–20%; reductions are staged at 20%–40%, followed by a 7–10 day review.
- Low inventory, margin below target, unsettled attribution, or incompatible date ranges must be visible constraints.
- Xiyou estimates and trends must be labeled third-party evidence, not Amazon actual performance.
- Do not execute changes in Amazon Ads; this skill produces recommendations and an execution checklist only.

## Verification

Before delivery, reconcile grouped totals to the search-term source, spot-check a repeated term across campaigns, confirm no duplicate action groups, scan formulas for errors, render every sheet, and repair clipped or unreadable content. Deliver exactly one final `.xlsx` file.
