# Input contract

## Files

| Input | Requirement | Use |
|---|---|---|
| Sponsored Products search-term report | Required | Search-term and ASIN action source of truth |
| Sponsored Products campaign report | Required | Campaign budget and efficiency diagnosis |
| Placement report | Recommended | Top-of-search, rest-of-search, and product-page comparison |
| Advertised-product report | Recommended | Advertised ASIN efficiency |
| Recent 30-day Business Report | Recommended | TACoS, total sales, sessions, and ad-sales share |
| ASIN margin/inventory file | Recommended | Break-even ACoS and inventory scaling constraints |
| AdsPilot analysis request JSON | Optional | Operator settings, source filenames, priority keywords, and main ASINs |

Accept `.xlsx`, `.xls`, or `.csv` for reports and `.json` for the AdsPilot request. Preserve localized headers and source filenames. The request JSON is operator input, not performance evidence.

## Required settings

- Marketplace country code and currency.
- Reporting start and end date.
- Target ACoS, plus break-even ACoS, margin, or allowable acquisition cost.
- Attribution settled confirmation; warn when the action-period end is less than about 48 hours before export.
- Main ASINs and inventory status for ASIN-level scaling or rank checks.

Defaults may be used only when explicitly labeled:

- Target ACoS: 30% only when no business threshold exists.
- No-order evidence: 8 clicks or spend reaching `target ACoS × representative order value`.
- Xiyou ABA lookback: 8 natural weeks ending at the report end date, maximum 52 weeks per call.
- Inventory safety: 14 days.

## Report validation

- Search-term report must contain campaign, customer search term, clicks, spend, sales, and orders.
- Preserve campaign and ad-group names verbatim.
- Do not infer currency from filenames when the report provides one.
- If date ranges or marketplaces conflict, record the mismatch and do not silently combine them.
- Missing evidence is `缺少数据`, never zero.

## AdsPilot request bundle

Read these keys when present:

- `skill`
- `generated_at`
- `reporting_period.start` and `.end`
- `parameters.marketplace`, `.currency`, `.target_acos`, `.break_even_acos`, `.min_no_order_clicks`, `.inventory_safety_days`
- `primary_asins`
- `priority_keywords`
- `source_files`
- `local_analysis_summary`

If a value conflicts with an official report, prefer the official report for measured facts and the request bundle for operator assumptions. Disclose the conflict.
