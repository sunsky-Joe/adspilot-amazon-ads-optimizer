# Xiyou MCP routing

Use one stable, desensitized `user_task` value for every Xiyou call made for the same operator request. Keep `intent_summary` specific to the current call. Do not put account details, links, emails, phone numbers, or complete ASINs in `user_task`.

## Candidate selection

Start from Amazon results and keep calls bounded:

1. Include all P1/P2 profitable exact-targeting keywords.
2. Include P1/P2 high-ACoS keywords when market demand affects whether to reduce bids or narrow targeting.
3. Include high-spend no-order keywords only to judge whether to negate exactly or isolate a smaller test; Amazon no-order evidence remains decisive.
4. Fill remaining capacity with the highest-spend observation terms.
5. Exclude ASIN-shaped search terms from keyword tools.

Query at most 50 unique keywords by default. Use top 10 keywords for rank checks and top 5 for competition deep dives unless the user requests broader coverage.

## Tool sequence

1. `get_keyword_info`
   - Batch the selected keywords for the marketplace.
   - Capture weekly search volume, ABA rank, competition difficulty, suggested bid, click conversion, and Top 3 ASIN shares.
2. `get_keyword_aba_trends`
   - Use for profitable expansion and important observation keywords.
   - Default to the 8 natural weeks ending at the report end date; never exceed 52 weeks in one call.
3. `get_keyword_asin_analysis`
   - Use for at most five expansion candidates where head-ASIN concentration or organic/ad competition changes the test decision.
4. `get_asin_keyword_rank_trends`
   - Use only when the operator supplied a main ASIN.
   - Query exact main-ASIN and priority-keyword pairs, normally no more than 10 combinations.
5. `get_asin_keyword_traffic_trends`
   - Use only when the user asks for traffic contribution or rank alone does not explain a material decision.

Use other Xiyou tools only when their returned field directly affects the requested advertising decision. Do not create a generic market-research detour.

## Response preservation

For every response retain:

- Tool name.
- Marketplace.
- Keyword and, when applicable, ASIN.
- Requested and returned date range.
- Raw response fields.
- Retrieval timestamp.
- A clear label: `第三方估算/趋势信号`.

When a call fails or a keyword is not returned, record the missing evidence. Do not replace it with a value from a different keyword, marketplace, or date.
