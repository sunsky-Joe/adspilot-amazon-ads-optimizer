# Amazon + Xiyou merge rules

Apply Amazon action classification before Xiyou enrichment. Xiyou changes context and execution priority, not the underlying Amazon performance class.

| Amazon result | Xiyou evidence | Combined action |
|---|---|---|
| Zero orders with sufficient evidence | High demand or rising trend | Keep exact negative when relevance is poor; when relevance is strong, isolate only a tightly capped test instead of broad phrase/category blocking. Do not call it profitable. |
| ACoS above target | High demand and healthy suggested bid | Reduce bid in stages and preserve exact relevance; do not broaden the negative solely to cut cost. |
| ACoS above target | Weak/declining demand | Reduce more cautiously within the 20%–40% guardrail and lower expansion priority. |
| ACoS at/below target with 3+ orders | High demand, rising ABA, or organic-rank gap | Prioritize exact targeting; increase only 10%–20% when delivery or placement evidence supports it. Track rank after 7–10 days. |
| ACoS at/below target with 1–2 orders | Favorable market signal | Keep as a small exact test, normally unchanged bid or no more than 10% increase. |
| Observation/data insufficient | High demand and rising trend | Add a P3 independent small-budget exploration test only when relevance is strong and inventory/margin allow it. |
| Any expansion candidate | Inventory below safety days or margin constraint failed | Mark `暂停扩量`; keep evidence but do not recommend a bid increase. |

Never merge keyword signals across marketplaces. Keep ASIN rank evidence tied to the exact ASIN-keyword pair. When source periods differ, show both periods and label the inference.
