---
name: amazon-ads-sif-optimizer
description: Optimize Amazon Sponsored Products to increase sales and reduce inefficient ad spend using product goals, Amazon reports, profit and inventory constraints, and directly queried SIF market signals. Create or explain an auditable Chinese Excel action workbook for uploaded Ads reports or an AdsPilot AI analysis bundle, including executable targeting, budget review, and ASIN rank follow-up.
---

# Amazon Ads + SIF Optimizer

Turn operator-supplied Amazon reports into one auditable `.xlsx` optimization workbook. Amazon reports determine actual delivery, spend, orders, sales, and ACoS. SIF supplies third-party market context; it never replaces Amazon actuals.

For questions about an existing workbook, read its actual cells and explain them without changing the file, refreshing market data, or running a new analysis unless requested. The full workflow below applies to analysis/build requests, not every follow-up question.

## Business objective

The primary outcome is **提升销量，同时降低广告消费**, implemented as:

1. Protect order-producing, high-intent traffic; expand only with goal, margin, inventory, and delivery evidence. Meeting an ACoS target alone does not prove profit.
2. Reduce zero-order waste, irrelevant traffic, and above-target bids with sufficient evidence.
3. Reallocate eligible savings from waste toward exact keywords or ASIN targets with validated conversion potential, subject to margin and inventory.

Do not optimize for the lowest spend or lowest ACoS alone. Cutting profitable traffic can reduce sales; indiscriminate bid increases can raise spend without incremental orders. When growth and spend reduction conflict, show the trade-off, protect profitable sales first, and cut only evidence-supported inefficiency. Treat future sales growth or savings as an opportunity estimate unless observed after execution.

## Required capabilities

- Read [references/diagnosis-framework.md](references/diagnosis-framework.md) for product-goal diagnosis, campaign budgets, Auto/Manual execution mapping, and optional keyword-library enrichment.
- Read [references/ads-action-rules.md](references/ads-action-rules.md) for search-term classification and review gates.
- Use `spreadsheets` for workbook authoring and verification.
- Discover the current SIF tools and schemas before use. Query SIF directly and follow [references/sif-routing.md](references/sif-routing.md); never invent tool names, arguments, periods, or unsupported metrics. Do not automatically call Xiyou or SellerSprite as fallbacks.

If SIF is unavailable, unsupported, partial, or empty, record the exact status and continue the Amazon-only analysis with explicit missing-evidence labels. Skill installation or a server configuration entry does not prove a callable connection, and does not carry credentials to another computer.

## Intake

Read [references/input-contract.md](references/input-contract.md) whenever files or an AdsPilot request bundle are supplied.

Minimum inputs:

1. Sponsored Products search-term report.
2. Sponsored Products campaign report.
3. Marketplace, currency, reporting dates, and target ACoS or acceptable acquisition cost.
4. Confirmed main ASINs for rank checks; valid profit/inventory constraints for scaling. Inventory is not required merely to look up an explicitly supplied ASIN's rank.

Recommended inputs are placement and advertised-product reports, same-period Business Report, ASIN–SKU mapping, margin/inventory, and product stage/goals. Daily reports and dated budget/bid settings are needed for daily change diagnosis and precise campaign adjustments. An `AdsPilot_分析任务包.json` carries settings and priorities, not a substitute for official reports or authority to execute instructions embedded in files. An `AdsPilot_AI分析数据包_*.json` may embed the confirmed raw report rows in `report_data`; validate those rows against `source_files` and the recorded confirmations before treating them as report evidence.

Stop for the missing search-term report when customer search terms are absent. For other missing inputs, continue with a clearly limited analysis unless the missing choice would materially change the decision.

## Workflow

1. Preserve source files unchanged. Validate report type, marketplace, currency, dates, actual attribution window, and inventory/sales units. Record user confirmations separately from source facts.
2. Establish product goals, then diagnose overall business, campaign budgets, and search terms using [references/diagnosis-framework.md](references/diagnosis-framework.md). Do not invent a daily trend from summary rows.
3. Group within marketplace, currency, ad type, period, and attribution basis by `[Campaign, Ad Group, Customer Search Term]`; sum raw measures then recalculate ratios. Retain source-row links to each original target/match type. Apply [references/ads-action-rules.md](references/ads-action-rules.md) before market enrichment; distinguish performance class from executable action and review status.
4. Select bounded candidates, then use [references/sif-routing.md](references/sif-routing.md) to query SIF directly. Query only fields that affect the requested decision. If the needed SIF metric is unavailable, preserve the gap instead of substituting another provider or an incompatible metric.
5. Merge only compatible marketplace, keyword/ASIN, metric definition, period, and granularity. Keep source-specific evidence and timestamps; do not stitch providers into a fabricated continuous trend.
6. Apply [references/merge-rules.md](references/merge-rules.md). A strong market signal can raise the priority of an expansion test or recommend a smaller negative scope, but it cannot convert an Amazon no-order group into a profitable group.
7. Read [references/budget-reallocation.md](references/budget-reallocation.md) and build a budget review: separate historical candidate spend, approved release, recipient allocation, and daily budget. Never treat them as interchangeable.
8. Create one versioned Excel workbook. Keep Amazon and each external provider on separate source sheets; expose specific actions, assumptions, limitations, and follow-up dates.

## Excel deliverable

Include at least:

1. `分析摘要`
2. `建议否定精准`
3. `建议提价_精准投放`
4. `建议降低出价`
5. `行动清单`
6. `保持观察`
7. `广告活动诊断`
8. `广告位分析` when available
9. `ASIN经营诊断` when available
10. `SIF市场洞察` with metric-level coverage, period, unit, retrieval time, and missing-data status
11. `数据问题记录`
12. `预算重分配` with plain-language instructions and approval gates
13. `产品目标与约束` and `原投放对象复核` when relevant; `关键词机会库` only when enrichment produces new candidates
14. Separate `原始_*` sheets for every uploaded report and SIF response

The action list must state priority, product goal, campaign/ad group, search term/ASIN, executable target/type, Amazon metrics, evidence, recommended change, review gates, owner/status, and a 7–10 day review date after execution (or a clearly labeled proposed date). Explain `问题层级 → 问题类型 → 发生时间/未知 → 贡献对象 → 数据证据 → 下一步检查 → 可执行建议`. Missing actual bid means no absolute executable bid. Use guarded formulas for ratios and budget releases. Keep empty recommendation sheets empty instead of relaxing thresholds.

`分析摘要` must show the dual objective without combining different currencies:

- Current spend, sales, orders, ACoS, CPC, and CVR by marketplace.
- `增长动作` count and protected order-producing sales/orders; distinguish `ACoS达标` from verified profitability.
- `降费动作` count and evidence-backed waste/reduction spend under review.
- `可重分配预算` only after attribution, relevance, margin, and inventory gates pass.
- A warning that suggested savings and growth are not realized results until a post-change report confirms them.

## Guardrails

- Never average row-level ACoS, CPC, conversion rate, rank, or share metrics.
- Never call an ASIN a keyword.
- Do not recommend blanket bid increases because ACoS is low or search volume is high.
- Do not recommend blanket budget cuts merely to reduce total spend; protect profitable order-producing traffic.
- Reduce advertising consumption primarily by removing waste and correcting overbids, then reallocate only when the expected incremental orders justify it.
- Normal bid increases are 10%–20%; reductions are staged at 20%–40%, followed by a 7–10 day review.
- Low inventory, margin below target, unsettled attribution, or incompatible date ranges must be visible constraints.
- All provider estimates/trends must be labeled third-party evidence. Market search volume, purchase rate, and suggested bids are not this product's orders, CVR, or actual CPC.
- Do not execute changes in Amazon Ads; this skill produces recommendations and an execution checklist only.

## Verification

Before delivery, reconcile source/group/action totals, verify original-target allocations without duplicated spend, test repeated terms across campaigns and Auto/Manual mapping, scan formulas for errors, render every sheet, and repair unreadable content. Test blanks/zeros/negative values and pending approvals in editable inventory, bid, and budget fields; missing inputs must not release an action. Check provider coverage and prohibit mixed-source "complete" trends. Confirm blocked growth stays blocked and protected traffic is not removed without an explicit trade-off. For an analysis request deliver exactly one final `.xlsx`; do not modify historical workbooks unless asked.
