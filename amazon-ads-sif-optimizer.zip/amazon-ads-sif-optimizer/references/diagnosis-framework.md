# Goal-led diagnosis and executable actions

Read before classifying uploaded reports. Use the optional keyword-library section only when enrichment or keyword discovery is in scope; do not turn routine ads optimization into a Listing rewrite.

## Product goals before ACoS judgments

Record marketplace, ASIN/SKU, product stage, operator objective, target ACoS, verified contribution margin, stock constraint, and owner. Keep unknowns explicit.

| Operator-confirmed role | Main checks | Decision boundary |
|---|---|---|
| Core/mature product | Total sales/orders, contribution, efficient traffic, budget limitation | Protect order sources; optimize inefficient segments instead of blanket cuts |
| New product / keyword-ranking test | Specified keyword/ASIN rank, conversion progress, test spend cap and deadline | An elevated ACoS may be an approved test cost, not proof of profit; no open-ended spending |
| Profit-priority product | Contribution margin, actual ACoS, total business results | A global target cannot override the product's verified economics |
| Unknown | Ask for stage/goal while continuing descriptive analysis | No invented launch goal, loss allowance, or growth approval |

Maintain the overall objective of higher sales and lower inefficient spend. Do not promise that both totals will improve; show the trade-off if a proposed growth test increases total spend. Do not infer that rank improvement was caused by ads alone.

## Diagnose from business to delivery

1. **Overall business:** reconcile comparable Business Report and ad metrics; show total sales, orders/units, sessions, ad spend, and TACoS when supported. Distinguish total-product conversion from ad CVR. A low ad ACoS alone does not prove business growth.
2. **Campaign:** separate budget limitation from insufficient delivery. With dated daily budgets, actual daily spend, out-of-budget status/hours or budget reports, assess `预算受限有证据`. A period-average utilization ratio alone is only a clue. Preserve budget changes/paused days; current budget × report days is not automatically a valid historical denominator.
3. **When budget is not spent:** inspect eligibility/status, inventory, relevance, bids/placements, and product-page conversion as possible checks. Do not prescribe a higher budget as the cure without evidence of budget limitation. Missing supporting data means `原因待核`, not a known cause.
4. **Search term and original target:** assess waste, conversions, long-tail concentration, and mixed winners/losers. Translate findings into the actual editable entity below.

Use the diagnostic record `问题层级 / 问题类型 / 首次变化日期或未知 / 贡献对象 / 原始数据证据 / 经营背景 / 下一步检查 / 建议动作 / 放行条件 / 复核日期`. Describe observed changes separately from possible causes.

## Daily changes when supported

- Use genuine daily data with compatible dates and settled attribution to compare equal windows and identify which campaigns/targets contributed to a change. Separate volume from efficiency: clicks/CPC for spend, orders/order value for sales, and sessions/conversion for business outcomes.
- Preserve additive metric deltas; recalculate ratios from summed numerators/denominators. Do not rank causal "ACoS contributions" by summing row-level ACoS changes. Describe a start date as observed, not a proven causal breakpoint.
- With summary-only reports, produce a period diagnosis and mark `缺逐日数据，无法定位发生日`. Do not prorate totals into daily rows. Review price/promotions, availability, listing changes, and seasonality only as evidence-backed context or explicit hypotheses.

## Search term is not always a bid target

| Evidence source | Correct execution object | Missing mapping behavior |
|---|---|---|
| Auto search term | Corresponding auto targeting group (close/loose/substitutes/complements), scoped negative, or proposed new Manual exact test | `需定位原投放组`; no per-search-term Auto bid |
| Manual keyword search term | Triggering keyword + match type / target ID; a query is not necessarily identical to the keyword | `需定位触发关键词`; do not change an arbitrary same-text target |
| Product/category targeting | Original product/category target; a searched ASIN may be a matched result rather than that exact target | Keep the searched ASIN separate; require original target mapping |
| Campaign budget | Actual campaign budget and effective date | Period spend and CPC cannot supply a missing budget |

Retain campaign/ad-group names verbatim, ad type, Auto/Manual, original target, match type, target ID if supplied, current bid, bidding strategy, and placement modifiers. If IDs are absent, use exact verified names plus target/match type and require duplicate-name review. Multiple findings on one editable entity need one reconciled proposal; avoid stacking percentage cuts or applying growth and cuts simultaneously.

Extracting a winner into Manual is a proposal to create a distinct target, not a reason to automatically negate or stop its converting Auto/source traffic. Check existing exact targets and total exposure before recommending duplication or migration.

## Optional keyword opportunity library

Use operator-specified competitors or supplied keyword files. If competitors are missing, continue with own search-term opportunities; ask before treating inferred competitors as the user's selected set.

- Collect only relevant routes: competitor-title expressions, ABA demand evidence, and competitor reverse-lookup traffic terms. Preserve original keyword, source, marketplace, ASIN, collection date, and metric period.
- Classify core need, precise intent, attribute, use case, and product/ASIN terms. Check each candidate against verified own-product attributes; competitor features do not establish own-product compatibility. Unconfirmed attributes remain unscored/pending.
- Keep `Listing候选` and `广告测试候选` distinct. Do not rewrite the Listing in this ads task. Market evidence or competitor rankings alone do not establish this product's conversion.
- Show market potential separately from own-product mature SP performance, with exact campaign/ad-group/term traceability. Do not add market scores to actual-performance scores and label the result predicted profit. Optional scores require disclosed inputs, missingness, weights, and trial-rule status, not an "Amazon algorithm" claim.
- A conceptual four-quadrant view is optional: supported demand + proven conversion (protect/test growth), supported demand + unproven conversion (capped validation), weak demand evidence + conversion (protect niche traffic), weak/unproven evidence (observe/review). Unknown market data is a separate unknown state, never "low demand".
- Feed later mature own-product results back into the library. For an actual test specify target, cap, duration, stop/review trigger, and what success would establish. This does not schedule an automation or authorize backend edits.

## Platform references

Amazon distinguishes customer queries from editable keywords/targets; Auto bids may apply at default or targeting-group level. See [Sponsored Products targeting](https://advertising.amazon.com/library/guides/targeting-with-sponsored-products). Budget diagnosis should distinguish out-of-budget campaigns from campaigns not spending their budgets; see [Sponsored Products budget guide](https://advertising.amazon.com/library/guides/sponsored-products-budget-best-practices). Verify current field definitions for the supplied report/account when needed; the skill's thresholds are operator heuristics.
