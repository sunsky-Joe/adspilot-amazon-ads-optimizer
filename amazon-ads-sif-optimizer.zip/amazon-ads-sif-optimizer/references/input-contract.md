# Input contract

## Files

| Input | Requirement | Use |
|---|---|---|
| Sponsored Products search-term report | Required | Search-term and ASIN action source of truth |
| Sponsored Products campaign report | Required | Campaign budget and efficiency diagnosis |
| Placement report | Recommended | Top-of-search, rest-of-search, and product-page comparison |
| Advertised-product report | Recommended | Advertised ASIN efficiency |
| Same-period Business Report | Recommended | TACoS, total sales, sessions, and ad-sales share |
| ASIN margin/inventory file | Recommended | Break-even ACoS and inventory scaling constraints |
| ASIN–SKU mapping and product goals | Recommended | Product ownership, stage, profit or ranking-test objective |
| Daily reports, targeting report, dated bid/budget settings | Conditional | Change timing, original-target actions, budget limitation diagnosis |
| AdsPilot analysis request JSON | Optional | Operator settings, source filenames, priority keywords, and main ASINs |

Accept `.xlsx`, `.xls`, or `.csv` for reports and `.json` for the AdsPilot request. Preserve localized headers and source filenames. The request JSON is operator input, not performance evidence.

## Required settings

- Marketplace country code and currency.
- Reporting start and end date.
- Target ACoS, plus break-even ACoS, margin, or allowable acquisition cost.
- Actual attribution-window fields and export timestamp; user confirmation is recorded separately, not a replacement for temporal validation.
- Main ASINs and inventory status for ASIN-level scaling or rank checks.

Defaults may be used only when explicitly labeled:

- Target ACoS: 30% only when no business threshold exists.
- No-order evidence: 8 clicks or spend reaching `target ACoS × representative order value`.
- Market trend lookback: 8 completed natural weeks ending on/before the report end when the current SIF interface supports that period and granularity; otherwise use only the compatible period actually returned and label the requested gap.
- Inventory safety: 14 days.

## Report validation

- Search-term report must contain campaign, customer search term, clicks, spend, sales, and orders.
- Preserve campaign and ad-group names verbatim.
- Do not infer currency from filenames when the report provides one.
- If date ranges or marketplaces conflict, record the mismatch and do not silently combine them.
- Missing evidence is `缺少数据`, never zero.
- Keep ad type and attribution windows separate; do not silently treat SB/SD as SP or count overlapping exports twice. Source coverage may differ across report types: show the discrepancy instead of forcing totals to match by deleting rows.

## Attribution and time basis

- Assess maturity using the actual attribution window, latest included row/end date, export time, and any known refresh lag. More than 48 hours alone does not establish maturity. A task-bundle `attribution_settled=true` cannot override a visibly open window.
- Use a comparable mature subperiod only when source granularity supports it. Do not split, prorate, or filter interval-summary rows by their start date to invent daily/mature data. Otherwise retain the full-period analysis as provisional and request re-export after the window closes.
- Assess each action group's dates where available; do not label all groups immature merely because the full report includes recent dates. Distinguish `日历窗口已过` from verified updated data.
- Business Report dates absent from its contents remain unknown until supported by export settings or explicit user confirmation. A filename is not proof. Record `用户确认同周期` with its date/scope instead of claiming the dates came from the CSV.
- Calculate TACoS only for comparable marketplace, currency, dates, sales scope, and tax basis with a positive total-sales denominator. `总销售额 − 广告归因销售额` is not a measured organic-sales field; label any residual as a limited accounting comparison, not actual natural sales.
- Declare ad-spend coverage: with only SP data, label `SP花费/总销售额（仅SP口径）`, not an unqualified all-advertising TACoS. Other ad types not supplied are unknown, not zero; include them in an overall ratio only when their compatible spend is available without duplication.

## Profit, inventory, and sales units

- Keep raw headers/values plus a separate interpreted unit and confirmation source. If a column named `日均销量` is confirmed to contain cumulative units, mark `累计销量，统计天数待核`; do not use it directly as daily demand or assume 30/31 days from the ads period.
- Only with a confirmed positive accumulation period and matching ASIN/SKU/sales-channel scope compute `日均销量 = 累计销量 / 统计天数`, then `可售天数 = 可售库存 / 日均销量` for a positive denominator. Missing/invalid inputs stay blank. Confirmed zero sales is different from missing; it does not imply zero coverage or a finite healthy stock-days value.
- Use product sales units for replenishment demand, not ad orders or ad-attributed units alone. Separate sellable, reserved, unsellable, and inbound stock, plus snapshot date and inbound availability; do not add inbound to immediately sellable stock without evidence. Safety days follow the user's replenishment plan; 14 days is only a disclosed fallback.
- Match profit/inventory to marketplace + ASIN + SKU and relevant snapshot. For conflicting duplicate rows, retain both sources and withhold a single authoritative margin/stock value; do not select the favorable row or sum potentially duplicate stock. Same ASIN with differing SKUs is a reference link, not proof their stock is interchangeable.
- Multi-ASIN ad-group membership does not allocate a search term's sales to one ASIN. Unknown ownership prevents product-specific profit claims and growth approval unless all relevant product constraints are verified and the action remains appropriate.
- Record advertising-before-contribution margin and included costs separately from target ACoS. A target above that margin is a profitability conflict, even when the global target is met. Ad-attributed cross-product sales cannot all be multiplied by the advertised ASIN's margin and called actual profit.
- Distinguish `目标设置高于利润约束` from `实际ACoS超过可比贡献利润率`. A high configured target alone does not establish current losses. Growth needs a reviewed economic ceiling or an explicitly funded exception; do not overwrite the operator's target silently. Even a positive margin-minus-ACoS difference is only a limited reference, not audited net profit.
- When the user corrects a basis, supersede the affected assumption, recompute dependent outputs, and withdraw unsupported warnings. Filling one inventory cell must not automatically clear all growth gates; require reanalysis/review.

## AdsPilot request bundle

Read these keys when present:

- `skill`
- `generated_at`
- `reporting_period.start` and `.end`
- `parameters.marketplace`, `.currency`, `.target_acos`, `.break_even_acos`, `.min_no_order_clicks`, `.inventory_safety_days`
- `primary_asins`
- `priority_keywords`
- Product stages, per-product targets, test caps/deadlines, and ASIN–SKU mapping when present
- `source_files`
- `report_time_confirmations`
- `report_data` with embedded headers/rows when the package is an `AdsPilot_AI分析数据包_*.json`
- `local_analysis_summary`

For an embedded AI analysis bundle, verify each required `source_files` entry has a matching confirmed time record and a corresponding `report_data` table before analysis. If a value conflicts with an official report, prefer the official report for measured facts and the request bundle for operator assumptions. Disclose the conflict.
