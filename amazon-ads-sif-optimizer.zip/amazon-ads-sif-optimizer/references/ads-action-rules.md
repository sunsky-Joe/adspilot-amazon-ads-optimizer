# Amazon advertising action rules

Use these rules after product-goal diagnosis and grouping each compatible report scope by `[Campaign, Ad Group, Customer Search Term]`. If ad group is absent, use `[Campaign, Customer Search Term]` for provisional analysis and mark execution scope unresolved. Never merge across campaigns, ad groups, marketplaces, currencies, ad types, or incompatible attribution windows. Preserve original-target source-row links for execution.

## Objective hierarchy

1. Increase attributable orders and sales from proven, relevant traffic.
2. Reduce inefficient advertising spend without cutting profitable sales.
3. Reallocate reviewed savings toward validated exact keyword or ASIN targets only when margin and inventory allow.

The practical objective is not “spend less at any cost.” It is “spend less on traffic that does not create profitable sales, and concentrate the remaining budget where orders are most likely.”

## Parameters

- Target ACoS: use the operator's value. If absent, infer it only from an explicit break-even margin; otherwise use 30% as a labeled working assumption.
- No-order evidence: default to 8 clicks or no-order spend reaching `target ACoS × representative order value`.
- Higher-evidence converting term: at least 3 orders with ACoS at or below the applicable product/business target; not proof of statistical significance or profit.
- Lower-volume converting test: 1–2 orders with ACoS at or below target.
- Severe inefficiency: ACoS at or above 100%.
- Review window: normally 7–10 days after an approved change.

These thresholds and bid-change bands are adjustable review heuristics, not Amazon rules or guarantees. Use comparable historical CVR and the source of representative order value to judge sample strength. Missing order value does not create a zero spend threshold. Exclude zero-click terms from bid actions. Apply the actual attribution-window checks in `input-contract.md`, not a fixed 48-hour maturity test.

Distinguish `表现分类`, `执行对象`, and `放行状态`. A funded, explicitly approved ranking/new-product test uses its documented cap, deadline, and progress targets; a stage label alone does not authorize losses or override inventory constraints. Missing product goals are `待确认`, not an inferred permission to spend more.

## Classification order

Apply the first matching rule so each isolated group receives one primary performance class. Execution remains conditional on the documented product objective, attribution, relevance, and original-target review. Never simultaneously release opposing actions for the same executable target.

1. **Zero-order waste / negative candidate — P1**
   - Orders equal zero; and clicks or spend meet the evidence threshold.
   - Ordinary term: `否定精准`. ASIN-shaped term: `否定商品投放`.
   - Gate execution on attribution maturity, relevance, and sample strength. High market demand alone cannot justify another test. For a strongly relevant low-sample term, prefer observation or a tightly capped, separately approved test if margin/inventory allow. Clearly irrelevant terms may be reviewed earlier with the relevance evidence documented.

2. **Severe ACoS / bid reduction — P1**
   - Orders are greater than zero and ACoS is at or above 100%.
   - Reduce in stages, normally 30%–40%, then review. Do not stop a relevant order-producing target without a separate decision.

3. **Above-target ACoS / bid reduction — P2**
   - Orders are greater than zero and ACoS is above target but below 100%.
   - Reduce in stages, normally 20%–30%, preserving exact relevance and monitoring order loss.

4. **ACoS达标转化 / growth candidate — P2**
   - At least 3 orders and ACoS at or below target.
   - Protect existing conversions; isolate or retain exact keyword/ASIN targeting. Increase bids by 10%–20% only when delivery, placement, margin, inventory, attribution, and product goals support incremental orders. Missing constraints mean `保护销量 / 暂缓扩量`, not automatic placement in the executable increase sheet.

5. **Lower-volume converting candidate — P3**
   - 1–2 orders and ACoS at or below target.
   - Prefer retaining the converting traffic. A small independent exact test, unchanged bid or at most 10% increase, requires the same growth gates and an explicit test cap.

6. **Observation**
   - Evidence does not justify a negative, reduction, or growth action.
   - Keep current settings and set a dated review trigger.

## Budget reallocation

Follow [budget-reallocation.md](budget-reallocation.md). Historical candidate spend is neither savings nor daily budget. Keep a campaign-level execution ledger separate from the account-level review pool; never double-count search-term and original-target views.

## Executable target and long-tail review

- Follow [diagnosis-framework.md](diagnosis-framework.md) for Auto/Manual mapping. CPC is observed spend/clicks, not the current bid. Calculate an absolute proposed bid only from a confirmed positive current bid and approved adjustment, with scope/relevance/attribution gates and applicable currency/platform limits. Otherwise keep it blank and show the percentage as a pending proposal.
- Where a term has multiple original targets, attribute each target's diagnostic spend/sales only from its underlying source rows. Do not repeat the entire term total against every target. Retain target/match-type identifiers and one reconciled execution decision per actual target.
- Aggregate individually low-sample, zero-order long tails at the original target to identify sustained waste; do not wait forever for every term to reach 8 clicks. Review the original target's conversions and total efficiency before proposing a source-bid reduction.
- A profitable/goal-compliant original target with some waste must not be blanket-cut. Prefer scoped negatives or isolation when justified, and expose the protected sales/orders at risk. Original-target review amounts overlap term-level spend and are not additional releasable money.
- A global ACoS pass with a verified contribution-margin conflict is `ACoS达标但利润待处理`; withhold growth, diagnose the margin gap, and request an approved goal/cost response. Do not call it profitable or rewrite its measured ACoS.

## Metric rules

- Sum impressions, clicks, spend, sales, orders, and units first.
- Recalculate `ACoS = spend / sales`, `CPC = spend / clicks`, and `CVR = orders / clicks` from totals.
- Leave ACoS blank when sales is zero. Leave CPC or CVR blank when clicks is zero.
- Never average row-level ACoS, CPC, CVR, ranks, or shares.
- Never assign both a cost-reduction and growth action to the same isolated group.
- Preserve ASIN display case, but use case-insensitive `^B0[A-Z0-9]{8}$` matching for classification.
- Flag orders greater than clicks for attribution/metric review; do not silently cap CVR at 100%, discard orders, or equate the flag alone with corrupt data.
