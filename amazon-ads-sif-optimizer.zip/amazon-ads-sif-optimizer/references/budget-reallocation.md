# Budget reallocation: review pool, not automatic savings

Read when producing or explaining `预算重分配`. Its purpose is to review money that might be shifted from inefficient traffic toward validated demand while protecting sales. It does not change Amazon settings.

## Explain the fields in the workbook

| Field | Meaning and boundary |
|---|---|
| 候选组历史花费 / 待降费花费 | Actual spend in the stated report period attached to distinct negative/reduction candidates; not realized savings, future savings, or daily budget |
| 降费执行及归因审核 | Whether relevance, settled performance, executable scope, and approved cost action have been reviewed; default pending |
| 人工核实可释放额 | Reviewer-entered amount with a time basis and release rationale; do not fill with the entire historical spend automatically |
| 审核后可释放额 | Amount admitted to the review pool only after gates; a plan amount, not a claim of measured savings |
| 利润库存相关性审核 | Recipient-specific margin, valid stock basis, relevance, goal, attribution, and delivery capacity checks |
| 拟重分配额 | Proposed amount to move from this reviewed pool, with the same currency and time basis |
| 放行重分配额 | Approved proposal only; not evidence that the change has been executed |
| 负责人 / 执行状态 / 复核日期 | Who reviews, who actually acts, and when to compare post-change evidence |

Blank formula output means `尚未核实/未放行`, not zero savings or a broken formula. Explicit verified zero must remain distinguishable from blank. Add these explanations as an in-sheet legend, not only in the chat handoff.

## Release gates and amounts

- Separate each marketplace/currency and define the pool's period/unit (for example, report-period USD). Deduplicate by source rows/action IDs; original-target and search-term views may overlap and cannot be added together again.
- In a same-period historical review pool, require `0 ≤ reviewed_release ≤ distinct_candidate_spend`, and `0 ≤ proposed_allocation ≤ approved_release`. This is a conservative pool ceiling, not a prediction that cutting an ad saves that amount.
- Explicitly check numeric type, finite values, status, and nonnegative bounds before formula release. Do not use a missing input coerced to zero to satisfy a gate. Missing/current-bid or stock-period data must not result in a released bid/recipient action.
- If an approval dropdown is editable, expose its evidence and reviewer; changing one label must not bypass known unresolved data constraints. Require each recipient's evidence and total-allocation reconciliation before marking all recipients passed.
- A projected saving is a labeled scenario with its own assumptions. Observed post-change spend reduction is a separate comparable-window measurement, not proof the action caused the entire difference. Also report orders/sales lost or gained.

## Account pool versus campaign execution

An account-level pool answers **how much may be considered for reassignment**, not **which campaign should receive it**. If current settings and supported recipients are absent, leave the latter pending rather than inventing allocations.

For campaign-specific proposals include: donor and recipient campaign/ad group/target, action ID, existing budget/bid and effective date, proposed budget/bid, currency, daily versus total-period unit, approved release source, test cap/duration, expected purpose, protected orders/sales, owner, gates, and review trigger. Reconcile recipient totals to the same-unit released pool. Do not deduct a term's spend twice just because several recommendations reference it.

Never paste a 30-day historical spend figure into a daily-budget field. A total-period allocation may be converted into a proposed daily increment only with an explicitly approved future duration and a documented conversion; it still is not guaranteed daily spend. Budget settings and actual spend can differ.

Prioritize recipients with verified conversion/relevance, viable margin/stock, and a demonstrated delivery or budget constraint. A separate small exploration test needs its own cap and approval. If the goal is to reduce total spend as well as waste, retain an explicitly chosen portion rather than automatically reinvesting the full released pool; do not invent a retention percentage.
