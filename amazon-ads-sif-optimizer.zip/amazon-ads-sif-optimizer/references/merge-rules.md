# Amazon + SIF market merge rules

Apply goal-aware Amazon performance classification before SIF enrichment. SIF evidence changes context and review priority, not actual Amazon metrics or the evidence required to execute. All test/increase rows below remain subject to attribution, relevance, product goals, actual-target mapping, margin, inventory, and an explicit cap when applicable.

| Amazon result | Compatible third-party evidence | Combined action |
|---|---|---|
| Zero orders with sufficient evidence | High demand or rising trend | Poor relevance supports scoped negatives; strong relevance can support observation or a separately gated capped test. Demand alone does not clear a test. Do not call it profitable. |
| ACoS above target | High demand and healthy suggested bid | Reduce bid in stages and preserve exact relevance; do not broaden the negative solely to cut cost. |
| ACoS above target | Weak/declining demand | Reduce more cautiously within the 20%–40% guardrail and lower expansion priority. |
| ACoS at/below target with 3+ orders | Supported demand growth, improving ABA rank (smaller number), or an organic-rank gap | Protect conversions and prioritize exact-target review; increase only 10%–20% after all growth gates pass. Track the same rank metric after 7–10 days. |
| ACoS at/below target with 1–2 orders | Favorable market signal | Keep as a small exact test, normally unchanged bid or no more than 10% increase. |
| Observation/data insufficient | High demand and rising trend | Add a P3 independent small-budget exploration test only when relevance is strong and inventory/margin allow it. |
| Any expansion candidate | Inventory below safety days, unresolved stock basis, margin conflict, or missing ownership | Mark `暂停/暂缓扩量`; keep evidence but do not release a bid increase. |

Join SIF signals only on compatible marketplace, exact keyword/ASIN pair, metric definition, unit, time granularity, and period. When periods or definitions differ, show both and label the comparison limited; do not average values or stitch them into one trend. Direct SIF query and coverage rules are in [sif-routing.md](sif-routing.md).

## Growth and spend-reduction balance

- A conversion-producing group deserves a protected-sales review even when total ad spend is being reduced. `ACoS达标` is not verified profit; show margin conflicts separately and do not automatically scale it.
- A zero-order or above-target group is a cost-reduction candidate, not a realized saving; apply attribution and relevance gates first.
- Reallocate approved savings only to exact keyword or ASIN targets that have Amazon conversion evidence or a clearly labeled small exploration test.
- No SIF search volume, purchase rate, or reference bid alone justifies spending more. Compatible market evidence plus own Amazon conversion, margin, inventory, and delivery constraints may raise a growth candidate's priority.
- Report `增长机会`, `待降费花费`, and `可重分配预算` separately. Do not net different currencies or present opportunity estimates as completed results.
