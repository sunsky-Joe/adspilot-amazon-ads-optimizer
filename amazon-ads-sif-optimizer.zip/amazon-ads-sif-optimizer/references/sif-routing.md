# Direct SIF market evidence routing

Read for SIF enrichment. Discover the currently exposed SIF tools, schemas, permitted marketplaces, periods, granularity, and returned metric definitions before calling them. The server may appear as `sif_mcp`, but configuration or a dependency entry is not proof of a callable connection. Do not hard-code an unverified endpoint, invent parameters, or claim weekly search-volume capability until the live schema and response establish it.

Use only SIF for third-party enrichment. Do not automatically fall back to Xiyou or SellerSprite. When SIF cannot supply a requested field, retain `缺少数据/接口不支持/当前会话不可用` and finish the Amazon-based analysis.

## Candidate selection

Start from Amazon results and keep calls bounded:

1. Prioritize P1/P2 conversion-backed, goal-compliant exact-targeting keywords.
2. Include P1/P2 high-ACoS keywords when SIF demand affects whether to reduce bids or narrow targeting.
3. Include high-spend no-order keywords only to judge whether to negate exactly or isolate a smaller test; Amazon no-order evidence remains decisive.
4. Fill remaining capacity with the highest-spend observation terms.
5. Exclude ASIN-shaped search terms from keyword tools.

Query at most 50 unique keyword-market pairs by default, with up to 20 priority terms for available trend periods, 10 exact ASIN-keyword rank pairs, and 5 competition deep dives unless broader coverage is requested. Deduplicate SIF lookups, not Amazon action groups. Respect API/credit limits; disclose coverage and ask before material unplanned expansion.

## Direct SIF lookup

1. Inspect the live SIF tool list and schemas.
2. Choose only interfaces whose returned fields materially affect the advertising decision, such as compatible keyword basics, trend, competition, suggested-bid, ASIN-keyword rank, or ASIN traffic evidence.
3. Pass the exact marketplace and keyword or ASIN-keyword pair. Do not translate, stem, or substitute a competitor ASIN for the user's main ASIN.
4. For trends, request the user-selected lookback only when supported. Preserve the actual returned period, dates, granularity, definition, and unit.
5. For main-ASIN rank, call only when the operator supplied or confirmed the ASIN and the keyword is relevant to that product. Keep natural rank, sponsored rank, placement, total rank, and traffic share as distinct fields.

If SIF returns monthly volume, keyword rank, traffic share, ad placement, or ASIN traffic, save those as separately labeled third-party evidence. They do not repair a requested weekly ABA-volume gap. Do not label SIF estimates as `ABA搜索量` unless SIF explicitly establishes that metric basis.

## Validity and stopping conditions

- A complete series needs the requested distinct periods, exact market/keyword, one consistent definition/unit, explicit dates, and finite nonnegative values that are not documented missing sentinels. Preserve explicit true zeros separately from missing values.
- Do not turn monthly volume into weekly estimates, interpolate gaps, or substitute rank/traffic share for search volume.
- Compute first-to-last percentage change only if the first valid value is positive and the date scope is stated. Zero baseline means percentage change is undefined. A partial series cannot support a complete-window trend classification.
- ABA search-frequency rank and ASIN position are different metrics. A smaller rank number generally indicates a better position, not lower volume. Do not infer a quantitative volume change from rank movement alone.
- Fix a demonstrable parameter error once using the actual schema; allow one bounded retry for a transient failure. Do not repeat successful-empty requests or cycle aliases looking for a favorable answer.
- Record authentication, quota, permission, unsupported-site, unsupported-period, and connection failures distinctly. Continue with Amazon actuals after the bounded attempt.

## Coverage statuses

Track request outcome separately from per-metric coverage, so `调用成功` never means `数据完整`.

| Status | Operator-facing interpretation |
|---|---|
| 未抽样查询 | Not looked up in this run; not evidence of no market |
| SIF MCP未连接/当前会话不可用 | Tool not callable; configuration alone was not verified |
| SIF接口不支持所需指标/站点/周期 | No compatible capability; do not substitute a different metric |
| 参数错误 / 认证或额度问题 / 调用失败 | Request problem with its specific reason; not empty market evidence |
| 返回空 / 返回词条但指标为空 | Response received but requested field unavailable |
| 部分有效 | Some compatible fields/periods; show valid/required count and missing items |
| 完整有效 | All required fields/periods for the stated metric and scope are valid |
| 补充信号，原缺口仍在 | Useful rank/traffic/monthly context but the requested evidence remains insufficient |

## Response preservation

For every response retain:

- Provider `SIF`, exact tool name, and request arguments without credentials.
- Marketplace.
- Keyword and, when applicable, ASIN.
- Requested and returned date range, period granularity, metric definition/unit, and period boundaries.
- Raw response fields and retrieval timestamp.
- A clear label: `SIF第三方估算/趋势信号`.
- Separate request status, per-field coverage, valid/required period count, and selected evidence source.

Keep raw SIF responses and a compact normalized evidence table keyed by marketplace + original/normalized keyword + ASIN (where relevant) + metric + period. Normalize whitespace/case for matching only; do not silently merge close variants. Never log tokens or account credentials.
